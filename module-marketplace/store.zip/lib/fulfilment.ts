/**
 * What happens once the money has actually arrived.
 *
 * This used to live inside the Stripe webhook, which meant PayPal had a second
 * copy of it and any third gateway would have needed a third. It is the
 * store's work, not a gateway's: mark the order paid, grant what was bought,
 * record the payment, email the buyer, run the delivery commands, and tell the
 * rest of the site. A gateway only reports that money moved.
 */
import { Prisma } from "@prisma/client";
import { prisma, log, grantRole } from "@/core/sdk/server";
import { sendOrderConfirmationEmail } from "./order-email";
import { deliverPaidOrder } from "./credit-order";
import { announceOrderCompleted, announceOrderRefunded } from "./order-events";
import { claimStock, releaseStock, stockClaims } from "./stock";
import { countSales, uncountSales } from "./popularity";
import { extendedExpiry } from "./ownership";
import { chestFieldsFor, recordedPlayerName, recordedVariables } from "./chest";
import { snapshotIn } from "./variants";
import { chargeShortfall } from "./charge";
import { cancelTopUp, findTopUp, refundTopUp, settleCredits } from "./credit-top-up";
import { revokeRefundedRoles, takeBackOrder, type GrantedRole } from "./take-back";
import { ALREADY, OK, failed, refused } from "./payment-outcome";
import { pastTheLimit } from "./availability-server";
import { payCommissionFor, takeBackCommission } from "./creator-commission";
import { issueThankYouCoupon, readThankYouSettings, type ThankYouCoupon } from "./thank-you-coupon";
import { pastCouponLimit } from "./coupon-limit";

/** Thrown inside a settlement to roll it back: the order would pass a limit. */
class PastTheLimit extends Error {
    constructor(readonly productId: string) {
        super("past the per-person limit");
    }
}

/** Thrown inside a settlement to roll it back: the buyer has used the order's coupon as often as it allows. */
class PastCouponLimit extends Error {
    constructor(readonly couponId: string) {
        super("past the coupon's per-customer limit");
    }
}

/**
 * Settles whatever the reference names: a top-up, or else an order.
 *
 * What a payment was for is read from the store's own rows, never from the
 * `kind` a gateway reported. Most gateways have no field to carry it in and
 * report everything as an order, which sent every top-up through them looking
 * for an order with the buyer's id.
 */
export async function settlePayment(settlement: PaymentSettlement): Promise<PaymentOutcome> {
    const topUp = await findTopUp(settlement.reference);
    return topUp ? settleCredits(settlement, topUp) : settleOrder(settlement);
}

/** The buyer never paid. Read from the store's rows for the same reason as `settlePayment`. */
export async function cancelPayment(reference: string): Promise<PaymentOutcome> {
    const topUp = await findTopUp(reference);
    return topUp ? cancelTopUp(topUp) : voidOrder(reference);
}

/**
 * Settles an order.
 *
 * Ownership is granted here and nowhere earlier: an order is created PENDING
 * at checkout and stays that way until a gateway says it was paid for.
 */
/** The part of the client `roleGrantedBy` needs, transaction or not. */
interface RoleReader {
    role: {
        findMany(args: {
            where: { id: { in: string[] } };
            select: { id: true; priority: true };
            orderBy: { priority: "desc" };
            take: number;
        }): Promise<{ id: string; priority: number }[]>;
    };
}

/**
 * The role a paid order grants, out of everything it bought.
 *
 * One product naming a role is the ordinary case and costs nothing to answer.
 * Two is the case that goes wrong silently: a member holds one role here, so
 * something has to lose, and "whichever line came last" would hand a buyer of
 * VIP and VIP+ whichever the cart happened to sort first. The highest priority
 * wins, which is the same order the rest of the platform ranks roles by.
 */
async function roleGrantedBy(
    client: RoleReader,
    grants: { grantsRoleId: string | null; durationDays: number | null }[],
): Promise<{ roleId: string; durationDays: number | null } | null> {
    const naming = grants.filter(
        (p): p is { grantsRoleId: string; durationDays: number | null } => Boolean(p.grantsRoleId),
    );
    if (naming.length === 0) return null;

    // The duration comes from the product that granted the role, not from
    // whatever else was in the basket: a thirty-day rank bought alongside a
    // permanent one must not become permanent.
    const chosen = naming.length === 1 ? naming[0] : await highestPriority(client, naming);
    return { roleId: chosen.grantsRoleId, durationDays: chosen.durationDays };
}

/** Of several products that each grant a role, the one that outranks the rest. */
async function highestPriority<T extends { grantsRoleId: string }>(
    client: RoleReader,
    naming: T[],
): Promise<T> {
    const ranked = await client.role.findMany({
        where: { id: { in: [...new Set(naming.map((p) => p.grantsRoleId))] } },
        select: { id: true, priority: true },
        orderBy: { priority: "desc" },
        take: 1,
    });
    const top = ranked[0]?.id;
    return naming.find((p) => p.grantsRoleId === top) ?? naming[0];
}

/**
 * How long a product bought in this order lasts: the variant's duration when
 * the line was bought as one that carries its own, otherwise the product's.
 * A basket holds a product once, so its first line is the one.
 */
function durationBought(
    product: { id: string; durationDays: number | null },
    lines: { productId: string | null; metadata: unknown }[],
): number | null {
    const line = lines.find((entry) => entry.productId === product.id);
    return snapshotIn(line?.metadata)?.durationDays ?? product.durationDays;
}

export async function settleOrder(settlement: PaymentSettlement): Promise<PaymentOutcome> {
    const order = await prisma.order.findUnique({
        where: { id: settlement.reference },
        include: { user: { select: { email: true, username: true, locale: true } }, items: true },
    });
    if (!order) {
        // Handled, so the provider stops retrying a reference that will never
        // exist, but loud: money arrived for it, and the gateway logs only
        // what was not handled. A top-up started before top-ups were written
        // down carries the buyer's id here.
        log.error("[store] a payment arrived for nothing the store knows", {
            reference: settlement.reference,
            provider: settlement.provider,
            providerRef: settlement.providerRef,
            amount: settlement.amount,
            currency: settlement.currency,
        });
        return failed("unknown order");
    }
    // Webhooks retry, and a buyer can reload a return URL. Both arrive here.
    if (order.status === "COMPLETED") return ALREADY;
    // A refunded order already gave back what it granted, and a replayed
    // success callback must not hand it all out again.
    if (order.status === "REFUNDED") return ALREADY;
    if (order.status === "CANCELLED") {
        // Settled by nothing: an operator who sees the money arrive marks the
        // order paid by hand, which opens it again first.
        log.error("[store] a payment arrived for a cancelled order", {
            orderId: order.id,
            provider: settlement.provider,
            providerRef: settlement.providerRef,
        });
        return failed("order is cancelled");
    }

    // What checkout asked the gateway to collect, converted and grossed up as
    // it was charged. An order placed before checkout wrote it down has
    // nothing to be held against, and settles as it always did.
    const charge =
        order.chargeAmount != null && order.chargeCurrency != null
            ? { amount: Number(order.chargeAmount), currency: order.chargeCurrency }
            : null;
    const shortfall = charge ? chargeShortfall(charge, settlement) : null;
    if (shortfall) {
        log.error("[store] an order was paid for with less than it was charged", {
            orderId: order.id,
            provider: settlement.provider,
            providerRef: settlement.providerRef,
            shortfall,
        });
        return refused(`payment does not match the charge: ${shortfall}`);
    }

    // Order.userId is nullable: the account can be deleted between paying and
    // the webhook landing. The order is still paid, so it stays COMPLETED, but
    // there is nobody left to grant anything to.
    const buyerId = order.userId;
    const buyer = order.user;
    const granted = buyerId ? order.items.filter((item) => item.productId) : [];
    const productIds = [...new Set(granted.map((item) => item.productId as string))];

    // Marking the order paid, granting what was bought and recording the
    // payment are one transaction or none of them.
    //
    // They used to run one after another. A process that died between the
    // status update and the grants left a buyer who had paid with a COMPLETED
    // order and an empty chest - and the duplicate guard above then refused
    // every webhook retry that would have fixed it, permanently.
    //
    // The status precondition is the other half. The read above is a
    // snapshot: a gateway retry and a reloaded return URL arriving together
    // both saw PENDING, both passed it, and both granted the same order. A
    // transaction does not close that on its own, exactly as it does not for
    // the credit balance at checkout; the condition in the `where` does, by
    // leaving the second one with nothing to update.
    // One clock for the whole settlement: two products bought together should
    // not end a millisecond apart because the loop took that long.
    const now = new Date();

    // Filled inside the transaction, granted after it. A role grant leaves the
    // displayed role true as its last act, which is a second write against a
    // row this transaction does not hold, and an account deleted between
    // paying and the webhook landing must not roll back an order somebody paid
    // for.
    const roleGrants: { userId: string; roleId: string; expiresAt: Date | null }[] = [];

    // Read before the claim: a settings lookup is not something to hold a
    // transaction open for.
    const thankYouSettings = buyerId ? await readThankYouSettings() : {};

    const settled = await prisma.$transaction(async (tx) => {
        const claimed = await tx.order.updateMany({
            where: { id: order.id, status: { in: ["PENDING", "PROCESSING"] } },
            data: {
                status: "COMPLETED",
                paymentMethod: settlement.provider,
                paymentId: settlement.providerRef,
            },
        });
        if (claimed.count === 0) return { settled: false, short: [] as string[], thanks: null as ThankYouCoupon | null };

        // The coupon's per-customer limit, counted again now that the money
        // is here, for the same reason as the product limit below: several
        // checkouts opened together each passed the count at checkout.
        // Thrown, so the claim rolls back with it.
        if (order.couponId && (await pastCouponLimit(tx, order.couponId, buyerId, now, order.id))) {
            throw new PastCouponLimit(order.couponId);
        }

        // Paid here, inside the claim, and nowhere at checkout: an order
        // nobody pays for earns its creator nothing, and a retried webhook
        // that loses the claim pays nothing twice.
        await payCommissionFor(tx, order);

        // Stock comes off the shelf here rather than at checkout: an order
        // nobody pays for must not hold anything. Inside the same claim as the
        // status, so a retried webhook cannot take it twice.
        const claims = stockClaims(order.items);
        const short = await claimStock(tx, claims);
        // Counted even where the shelf came up short: the unit sold, and the
        // ranking describes sales rather than what is left.
        await countSales(tx, claims);

        if (buyerId && granted.length > 0) {
            // The name and the answers travel with the item. Claiming it
            // later has no form to read them from, and the account's username
            // is the one name checkout deliberately did not use.
            const deliverTo = recordedPlayerName(order.metadata);
            await tx.chestItem.createMany({
                data: granted.map((item) => ({
                    userId: buyerId,
                    productId: item.productId as string,
                    productName: item.name,
                    ...chestFieldsFor(item),
                    orderId: order.id,
                    playerName: deliverTo,
                    variables: recordedVariables(item.metadata) ?? Prisma.JsonNull,
                })),
            });

            // What each product grants beyond the row itself. Read here rather
            // than added to the stock query above: that one asks only about
            // products the shop counts, and widening it would make every
            // settlement carry columns the shelf has no use for.
            const grants = await tx.product.findMany({
                where: { id: { in: productIds } },
                select: { id: true, durationDays: true, grantsRoleId: true, perPersonLimit: true, perPersonPeriod: true },
            });

            // The per-person limit again, now that the money is here: every
            // checkout counted before it was paid, and several paid together
            // each passed. Thrown, so the claim and the chest rows above roll
            // back with it.
            const past = await pastTheLimit(tx, grants, granted, buyerId, now, order.id);
            if (past) throw new PastTheLimit(past);
            // A variant's own duration stands in for the product's: six
            // months of a rank is the variant the buyer paid for, read from
            // what the line kept rather than from the product now.
            const lasting = grants.map((product) => ({ ...product, durationDays: durationBought(product, granted) }));
            const timed = lasting.filter((p) => p.durationDays !== null && p.durationDays > 0);
            const timedIds = new Set(timed.map((p) => p.id));
            const outright = productIds.filter((id) => !timedIds.has(id));

            // One row per product, however many of it was bought: the unique
            // key is (userId, productId), and owning it twice means nothing.
            // Still one statement for the whole order, because owning a thing
            // outright is the common case and must not cost a query a line.
            if (outright.length > 0) {
                await tx.ownedProduct.createMany({
                    data: outright.map((productId) => ({ userId: buyerId, productId, orderId: order.id })),
                    skipDuplicates: true,
                });
            }

            // A timed product has to be read before it is written: the new end
            // date depends on what is left of the old one. See `ownership.ts`
            // for why it extends rather than replaces.
            if (timed.length > 0) {
                const held = await tx.ownedProduct.findMany({
                    where: { userId: buyerId, productId: { in: [...timedIds] } },
                    select: { productId: true, expiresAt: true },
                });
                const endsAt = new Map(held.map((row) => [row.productId, row.expiresAt]));
                for (const product of timed) {
                    const expiresAt = extendedExpiry(
                        endsAt.get(product.id) ?? null,
                        product.durationDays,
                        now,
                    );
                    await tx.ownedProduct.upsert({
                        where: { userId_productId: { userId: buyerId, productId: product.id } },
                        create: { userId: buyerId, productId: product.id, orderId: order.id, expiresAt },
                        update: { expiresAt, orderId: order.id },
                    });
                }
            }

            const granting = await roleGrantedBy(tx, lasting);
            if (granting) {
                // A rank is added to what the buyer already holds rather than
                // replacing it. The shape this replaces held one role per
                // member, so selling somebody a rank took away whatever else
                // they were - a moderator who bought one stopped moderating
                // until it lapsed.
                const until =
                    granting.durationDays !== null
                        ? (extendedExpiry(null, granting.durationDays, now) as Date)
                        : null;

                // Outside the transaction's `tx` on purpose: the grant leaves
                // the displayed role true as its last act, which is a second
                // write this module must not be the one to remember. An
                // account deleted between paying and the webhook landing makes
                // this throw, and the catch below keeps that from rolling back
                // an order somebody paid for.
                roleGrants.push({ userId: buyerId, roleId: granting.roleId, expiresAt: until });
            }
        }

        await tx.payment.create({
            data: {
                orderId: settlement.reference,
                provider: settlement.provider,
                providerId: settlement.providerRef,
                // What the provider reported, or, when it reports nothing, what
                // was charged: the settlement passed the check above either way.
                amount: settlement.amount ?? charge?.amount ?? Number(order.total),
                currency: (settlement.currency ?? charge?.currency ?? order.currency).toLowerCase(),
                status: "COMPLETED",
                ...(settlement.metadata ? { metadata: settlement.metadata } : {}),
            },
        });

        // Inside the claim, so the coupon exists exactly when the paid order
        // does: a limit that rolls the settlement back takes it too.
        const thanks = await issueThankYouCoupon(
            tx,
            { id: order.id, orderNumber: order.orderNumber, userId: buyerId, total: Number(order.total) },
            thankYouSettings,
            now,
        );
        return { settled: true, short, thanks };
    }).catch((error: unknown) => {
        if (error instanceof PastTheLimit) {
            return { settled: false, short: [] as string[], thanks: null as ThankYouCoupon | null, past: error.productId };
        }
        if (error instanceof PastCouponLimit) {
            return { settled: false, short: [] as string[], thanks: null as ThankYouCoupon | null, coupon: error.couponId };
        }
        throw error;
    });

    // Refused like the per-person limit below, and for the same reason: the
    // money arrived for a discount this customer had already used up, and an
    // operator has to refund it. A retry settles it if the order holding the
    // use was refunded in the meantime.
    if ("coupon" in settled) {
        log.error("[store] a paid order uses a coupon past its per-customer limit; refund it", {
            orderId: order.id,
            couponId: settled.coupon,
            provider: settlement.provider,
            providerRef: settlement.providerRef,
        });
        return refused(`order passes the per-customer limit of coupon ${settled.coupon}`);
    }

    // Refused rather than acknowledged, like a short payment: the money
    // arrived for more than this member may buy, and an operator has to
    // refund it. A retry settles it if the order that filled the limit was
    // refunded in the meantime.
    if ("past" in settled) {
        log.error("[store] a paid order would pass a per-person limit; refund it", {
            orderId: order.id,
            productId: settled.past,
            provider: settlement.provider,
            providerRef: settlement.providerRef,
        });
        return refused(`order passes the per-person limit of ${settled.past}`);
    }

    // Another delivery of the same payment got there first.
    if (!settled.settled) return ALREADY;

    for (const grant of roleGrants) {
        try {
            await grantRole(grant.userId, grant.roleId, {
                expiresAt: grant.expiresAt,
                source: "store:product",
            });
        } catch (error) {
            // The buyer's account went between paying and this running. The
            // order is settled either way; a rank nobody can hold is not a
            // reason to fail a payment that has already been taken.
            log.error("[store] a paid rank could not be granted", {
                userId: grant.userId,
                roleId: grant.roleId,
                error: error instanceof Error ? error.message : String(error),
            });
        }
    }

    // The money moved before this ran, so a shelf that could not cover the
    // order is not something to refuse: the buyer paid and is granted what
    // they bought. It is an error because a shop that oversold will otherwise
    // hear it from a customer first.
    if (settled.short.length > 0) {
        log.error("[store] an order took more than the shelf had", {
            orderId: order.id,
            products: settled.short,
        });
    }

    if (!buyerId || !buyer) {
        log.warn("[store] order paid for by an account that no longer exists", { orderId: order.id });
        return OK;
    }

    // Neither of these may hold up the answer to the gateway: the order is
    // paid and granted either way, and a webhook left waiting gets retried.
    sendOrderConfirmationEmail({
        to: buyer.email,
        orderNumber: order.orderNumber,
        total: Number(order.total),
        locale: buyer.locale,
        coupon: settled.thanks,
    }).catch((error: unknown) =>
        log.error("[store] order confirmation email failed", { orderId: order.id, error: String(error) }),
    );

    const playerName =
        settlement.metadata?.playerName ||
        ((order.metadata as Record<string, unknown>)?.playerName as string) ||
        buyer.username ||
        "Player";

    // Not awaited: a gateway's webhook has a timeout, and a slow game server
    // must not make the provider think the payment went unrecorded.
    deliverPaidOrder(
        { id: order.id, orderNumber: order.orderNumber, items: granted },
        { name: playerName, id: null, userId: buyerId },
    ).catch((error) => log.error("[store] delivery failed", { orderId: order.id, error: String(error) }));

    await announceOrderCompleted(order.id);
    return OK;
}

/** The buyer walked away, or the gateway's session expired. */
export async function voidOrder(reference: string): Promise<PaymentOutcome> {
    const order = await prisma.order.findUnique({ where: { id: reference } });
    if (!order) return failed("unknown order");
    // A paid order is never cancelled by a late "expired" event.
    if (order.status === "COMPLETED") return ALREADY;
    if (order.status === "CANCELLED") return ALREADY;
    // A refund is not undone into a cancellation.
    if (order.status === "REFUNDED") return ALREADY;
    await prisma.order.update({ where: { id: reference }, data: { status: "CANCELLED" } });
    return OK;
}

/** The money went back, whether the buyer asked or the operator did. */
export async function refundPayment(provider: string, providerRef: string): Promise<PaymentOutcome> {
    const payment = await prisma.payment.findFirst({ where: { provider, providerId: providerRef } });
    // A top-up writes no payment row; its refund is found by the same reference.
    if (!payment) return refundTopUp(provider, providerRef);
    if (payment.status === "REFUNDED") return ALREADY;

    const refundedOrder = await prisma.order.findUnique({
        where: { id: payment.orderId },
        include: { items: true },
    });

    // The status precondition is what makes two refund notifications safe: the
    // read above is a snapshot, and without it both would put the same stock
    // back and the shelf would grow.
    const refunded = await prisma.$transaction(async (tx) => {
        const claimed = await tx.payment.updateMany({
            where: { id: payment.id, status: { not: "REFUNDED" } },
            data: { status: "REFUNDED" },
        });
        if (claimed.count === 0) return null;
        await tx.order.update({ where: { id: payment.orderId }, data: { status: "REFUNDED" } });
        if (!refundedOrder) return [] as GrantedRole[];
        // The creator's cut goes back with the money, in the same claim.
        await takeBackCommission(tx, refundedOrder);
        const claims = stockClaims(refundedOrder.items);
        await releaseStock(tx, claims);
        await uncountSales(tx, claims);
        return takeBackOrder(tx, refundedOrder);
    });
    if (!refunded) return ALREADY;

    await revokeRefundedRoles(refunded);
    // The cashback is the wallet's to take back; it hears of the refund here.
    await announceOrderRefunded(payment.orderId);
    return OK;
}

/**
 * Records what a gateway says about a recurring plan.
 *
 * The store keeps the subscription row because access to the product is the
 * store's business; the gateway keeps the plan itself. An ended plan takes the
 * product with it, which is the whole point of selling access by the month.
 */
export async function applySubscriptionChange(change: SubscriptionChange): Promise<PaymentOutcome> {
    const existing = await prisma.subscription.findFirst({
        where: { stripeSubscriptionId: change.providerRef },
    });

    if (change.ended) {
        if (!existing) return failed("unknown subscription");
        if (existing.status === "canceled") return ALREADY;

        // Cancelling the plan and taking the product back are one step. Done
        // in sequence, a process that died between them left the plan
        // cancelled and the product still owned - and the guard above then
        // answered every retry with ALREADY, so the subscriber kept what they
        // had stopped paying for. The condition in the `where` is what makes
        // two "ended" events arriving together safe.
        const ended = await prisma.$transaction(async (tx) => {
            const claimed = await tx.subscription.updateMany({
                where: { id: existing.id, status: { not: "canceled" } },
                data: { status: "canceled", canceledAt: new Date() },
            });
            if (claimed.count === 0) return false;
            await tx.ownedProduct.deleteMany({
                where: { userId: existing.userId, productId: existing.productId },
            });
            return true;
        });
        return ended ? OK : ALREADY;
    }

    const periodEnd = change.currentPeriodEnd ? new Date(change.currentPeriodEnd) : null;

    if (existing) {
        await prisma.subscription.update({
            where: { id: existing.id },
            data: { status: change.status, ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}) },
        });
        return OK;
    }

    // Same again in the other direction: a new plan and the product it grants
    // arrive together or not at all. Written in sequence, a failure in between
    // left a subscription row with nothing granted, and the retry found that
    // row, took the branch above, and only updated its status - so the
    // subscriber paid every month for a product they never received.
    await prisma.$transaction(async (tx) => {
        await tx.subscription.create({
            data: {
                userId: change.userId,
                productId: change.productId,
                stripeSubscriptionId: change.providerRef,
                status: change.status,
                currentPeriodEnd: periodEnd ?? new Date(),
            },
        });
        await tx.ownedProduct.upsert({
            where: { userId_productId: { userId: change.userId, productId: change.productId } },
            update: {},
            create: { userId: change.userId, productId: change.productId },
        });
    });
    return OK;
}
