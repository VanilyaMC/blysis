import { NextRequest, NextResponse } from "next/server";
import { moduleSettings, prisma, rateLimitForRole, readJsonBody } from "@/core/sdk/server";
import { auth } from "@/core/sdk/auth";
import { couponValidateSchema } from "../../../lib/validations";
import { computeCouponDiscount, scopedSubtotal } from "../../../lib/pricing";
import { priceCartLines } from "../../../lib/cart-pricing";
import { saleAdjustedPrice } from "../../../lib/store-sale-server";
import { creditingPurchases, ownedRungsOn } from "../../../lib/upgrade-credit-server";
import { couponOpenTo } from "../../../lib/thank-you-coupon";
import { customerUses } from "../../../lib/coupon-limit";
import { basketLinePrice } from "../../../lib/variants";

// POST /api/v1/store/coupons/validate - Check coupon validity
export async function POST(request: NextRequest) {
    const session = await auth();
    if (!session?.user) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const rl = await rateLimitForRole(
        `coupon:${session.user.id}`,
        { maxRequests: 10, windowMs: 60_000 },
        session.user.role
    );
    if (!rl.success) {
        return NextResponse.json({ error: "Too many requests" }, { status: 429 });
    }

    const { enableCoupons } = await moduleSettings<{ enableCoupons: boolean }>("store");
    if (!enableCoupons) {
        return NextResponse.json({ valid: false, code: "coupons_off" });
    }

    const jsonBody = await readJsonBody(request);
    if (jsonBody instanceof NextResponse) return jsonBody;
    const parsed = couponValidateSchema.safeParse(jsonBody);
    if (!parsed.success) return NextResponse.json({ error: "Code required" }, { status: 400 });
    const { code } = parsed.data;

    const coupon = await prisma.coupon.findUnique({
        where: { code: code.toUpperCase() },
    });
    // Somebody else's personal coupon answers exactly as a code that does not
    // exist, so the preview cannot be used to find out that one does.
    if (!coupon || !couponOpenTo(coupon, session.user.id)) {
        return NextResponse.json({ valid: false, code: "coupon_unknown" });
    }

    /*
     * The basket is read here rather than taken from the request.
     *
     * The browser used to send what it thought the cart was worth, and the
     * answer - including whether a minimum purchase had been met - was
     * computed from it. It also cannot say which products are in the basket,
     * which is what a coupon scoped to a shelf has to know.
     */
    const cartItems = await prisma.cartItem.findMany({
        where: { userId: session.user.id },
        include: { product: { select: { id: true, price: true, categoryId: true, salePrice: true, saleFrom: true, saleUntil: true, variants: true } } },
    });
    // From the price the checkout charges, so a minimum purchase is met or
    // missed here exactly as it will be there.
    const listedAt = await saleAdjustedPrice(new Date());
    const basket = cartItems.map((item) => ({
        productId: item.product.id,
        categoryId: item.product.categoryId ?? null,
        price: basketLinePrice(item.product, item.variantId, listedAt(item.product)),
        quantity: item.quantity,
    }));
    const ownedIds = await creditingPurchases(session.user.id);
    const { lines, subtotal: cartSubtotal } = priceCartLines(
        basket,
        ownedIds,
        await ownedRungsOn(basket.map((line) => line.categoryId), ownedIds),
    );

    // The same function the checkout charges by.
    //
    // This route used to repeat the rules, and had drifted on one of them: a
    // fixed-value coupon was previewed at its full face value while the
    // checkout caps it at the subtotal, so a 50 coupon on a 10 cart promised
    // a shopper 50 off and then took 10. A preview that disagrees with the
    // till is worse than no preview.
    const eligible = scopedSubtotal(
        coupon,
        lines.map((line) => ({ productId: line.productId, price: line.payPrice, quantity: line.quantity })),
        lines.map((line) => ({ id: line.productId, categoryId: line.categoryId })),
    );
    const now = new Date();
    const used = coupon.perCustomerLimit ? await customerUses(prisma, coupon.id, session.user.id, now) : 0;
    const priced = computeCouponDiscount(coupon, cartSubtotal, now, eligible, used);

    if (priced.code) {
        /*
         * Why a coupon failed is deliberately not spelled out: one that never
         * existed and one that has run out answer the same, so the response
         * cannot be used to go looking for codes. Two are exceptions, because
         * they are the two a shopper can act on - spend more, or put
         * something the offer covers in the basket. The third is told
         * because it gives nothing away: only somebody who already used
         * the code hears that they have.
         */
        const tellable =
            priced.code === "coupon_min_purchase" ||
            priced.code === "coupon_not_for_these_items" ||
            priced.code === "coupon_already_used";
        return NextResponse.json({
            valid: false,
            code: tellable ? priced.code : "coupon_unknown",
            ...(priced.code === "coupon_min_purchase" ? { minPurchase: Number(coupon.minPurchase) } : {}),
        });
    }

    return NextResponse.json({
        valid: true,
        coupon: {
            code: coupon.code,
            type: coupon.type,
            value: Number(coupon.value),
            discount: priced.discount,
        },
    });
}
