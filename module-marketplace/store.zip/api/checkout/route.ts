import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { generateOrderNumber, applyFiltersAsync } from "@/core/sdk";
import { getClientIP, log, logActivity, moduleSettings, prisma, rateLimitForRole, readJsonBody, siteTimeZone } from "@/core/sdk/server";
import { auth } from "@/core/sdk/auth";
import { claimStock, shortOfStock, stockClaims } from "../../lib/stock";
import { countSales } from "../../lib/popularity";
import { createCreditOrder, deliverPaidOrder, OUT_OF_STOCK } from "../../lib/credit-order";
import { offerPrice, runningCampaignEntries } from "../../lib/campaign-server";
import { withStoreSale } from "../../lib/store-sale";
import { runningStoreSales } from "../../lib/store-sale-server";
import { availabilityFor, pastTheLimit, rulesOf, type ProductRow } from "../../lib/availability-server";
import { customerUses, pastCouponLimit } from "../../lib/coupon-limit";
import { convertedCharge, resolveCurrency } from "../../lib/currency";
import { startPaymentSession, listPaymentProviders } from "../../lib/payments";
import { paymentFeeFor } from "../../lib/payment-fee-server";
import { announceOrderCreated, announceOrderCompleted } from "../../lib/order-events";
import { recordedVariables } from "../../lib/chest";
import { billingRefusal, normaliseBilling, type BillingDetails } from "../../lib/billing";
import { processorTaxLine, taxRecord } from "../../lib/tax";
import { headerReader, resolveTax } from "../../lib/tax-server";
import {
    computeOrderPricing,
    computeCouponDiscount,
    scopedSubtotal,
    computeCreatorDiscount,
    computeTotals,
    grossUpForFee,
} from "../../lib/pricing";
import { creditingPurchases, ownedRungsOn } from "../../lib/upgrade-credit-server";
import { z } from "zod";
import { isPlayerName } from "../../lib/player-name";
import { payCreatorCommission } from "../../lib/creator-commission";
import { couponOpenTo } from "../../lib/thank-you-coupon";

const LIMIT_REACHED = "LIMIT_REACHED";
const COUPON_ALREADY_USED = "COUPON_ALREADY_USED";

const checkoutSchema = z.object({
    items: z.array(z.object({
        productId: z.string({ message: "Product is missing" }),
        // The most a cart holds of one line (`api/cart/route.ts`). Without it a
        // free line, or one that runs its commands per unit, delivered any count.
        quantity: z.number().int().min(1, "Quantity must be at least 1").max(99, "Quantity must be at most 99"),
    }), { message: "Your cart is empty" }).min(1, "Your cart is empty"),
    playerName: z
        .string()
        .trim()
        .min(1, "Player name is required")
        .max(50, "Player name is too long")
        .refine(isPlayerName, "A player name has only the letters a to z, digits and _ . -, with no spaces"),
    couponCode: z.string().optional(),
    creatorCode: z.string().optional(),
    variables: z.record(z.string(), z.record(z.string(), z.string())).optional(),
    notes: z.string().optional(),
    // Any installed gateway's id, or "credits" for the wallet the store runs
    // itself. Checked against the installed gateways below rather than against
    // a list written here: the whole point of the payment contract is that
    // this file does not know which gateways exist.
    paymentMethod: z.string().min(1).max(32).default("stripe"),
    /**
     * Who to make the invoice out to. Bounded here and checked for
     * completeness below, once the store knows whether anything reads it.
     */
    billingDetails: z.object({
        kind: z.enum(["individual", "company"]),
        name: z.string().max(200),
        taxNumber: z.string().max(40),
        taxOffice: z.string().max(120),
        address: z.string().max(300),
        city: z.string().max(120),
        country: z.string().max(60),
    }).optional(),
});

// POST /api/v1/store/checkout - Create checkout session
export async function POST(request: NextRequest) {
    try {
        const session = await auth();
        if (!session?.user) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        // Every call opens a session at the payment gateway, which costs a
        // request there whether or not anyone pays. A budget, not a
        // brute-force ceiling, so role multipliers apply.
        const rl = await rateLimitForRole(
            `store-checkout:${session.user.id}`,
            { maxRequests: 20, windowMs: 15 * 60 * 1000 },
            session.user.role,
        );
        if (!rl.success) {
            return NextResponse.json({ error: "Too many requests" }, { status: 429 });
        }

        const body = await readJsonBody(request);
        if (body instanceof NextResponse) return body;
        const validation = checkoutSchema.safeParse(body);
        if (!validation.success) {
            return NextResponse.json({ error: validation.error.issues[0].message }, { status: 400 });
        }

        const { items, playerName, couponCode, creatorCode, variables, notes, paymentMethod } = validation.data;
        const sentBilling = validation.data.billingDetails as BillingDetails | undefined;

        // ── Fetch products ──
        const productIds = items.map((i) => i.productId);
        const products = await prisma.product.findMany({
            where: { id: { in: productIds }, isActive: true },
            include: { category: { select: { id: true } } },
        });

        if (products.length !== items.length) {
            return NextResponse.json({ error: "Some products are not available" }, { status: 400 });
        }

        // ── Check each product is for sale, to this person, right now ──
        //
        // The list and the buy button ask the same question, but this is the
        // one that has to be true: a limit enforced only where a browser can
        // see it is not a limit. A window that closed while somebody sat on
        // the checkout page closes here too.
        const zone = await siteTimeZone();
        const now = new Date();
        for (const product of products) {
            const wanted = items.find((i) => i.productId === product.id)?.quantity ?? 1;
            const state = await availabilityFor(prisma, product as unknown as ProductRow, session.user.id, now, zone);
            if (!state.buyable) {
                return NextResponse.json(
                    {
                        error: `${product.name}: ${state.state}`,
                        code: `store_${state.state}`,
                        productId: product.id,
                        opensAt: state.opensAt,
                    },
                    { status: 409 },
                );
            }
            if (state.remainingForPerson !== null && wanted > state.remainingForPerson) {
                return NextResponse.json(
                    {
                        error: `${product.name}: limit_reached`,
                        code: "store_limit_reached",
                        productId: product.id,
                        remaining: state.remainingForPerson,
                    },
                    { status: 409 },
                );
            }
            if (state.remainingInPeriod !== null && wanted > state.remainingInPeriod) {
                return NextResponse.json(
                    {
                        error: `${product.name}: sold_out_for_now`,
                        code: "store_sold_out_for_now",
                        productId: product.id,
                        opensAt: state.opensAt,
                    },
                    { status: 409 },
                );
            }
        }

        // ── Check subscription constraints ──
        const subscriptionProducts = products.filter((p) => p.type === "SUBSCRIPTION");
        if (subscriptionProducts.length > 1) {
            return NextResponse.json({ error: "Only one subscription product per checkout is allowed" }, { status: 400 });
        }
        if (subscriptionProducts.length === 1 && items.length > 1) {
            return NextResponse.json({ error: "Subscription products must be purchased separately" }, { status: 400 });
        }
        const isSubscriptionCheckout = subscriptionProducts.length === 1;

        // Subscriptions cannot be paid with credits
        if (isSubscriptionCheckout && paymentMethod === "credits") {
            return NextResponse.json({ error: "Subscriptions cannot be paid with credits" }, { status: 400 });
        }

        // ── Credits-only store ──
        // With the setting on, money reaches the shop only through a top-up and
        // every order is paid from the balance. Checked here, on what was sent,
        // because the cart hiding the gateways is a courtesy: a request naming
        // one is refused, a free order included, so there is no total that
        // opens the door. A subscription is refused too: it renews by charging
        // a gateway, which is the one thing this mode rules out.
        //
        // Tax stays on the order, below, as it is in the normal mode. A balance
        // spendable on anything in the shop is taxed when it is spent, on the
        // thing bought, not when it is loaded; that also keeps one tax record
        // per sale for an invoice. The payment method's fee is the opposite:
        // it is charged on the top-up, where a gateway is used, and an order
        // paid from the balance carries none.
        const { creditsOnlyStore } = await moduleSettings<{ creditsOnlyStore?: boolean }>("store");
        if (creditsOnlyStore === true) {
            if (isSubscriptionCheckout) {
                return NextResponse.json(
                    { error: "Subscriptions are not sold while the store takes only credits", code: "store_credits_only_subscription" },
                    { status: 400 },
                );
            }
            if (paymentMethod !== "credits") {
                return NextResponse.json(
                    { error: "This store takes only credits. Load credits first, then pay with them.", code: "store_credits_only" },
                    { status: 400 },
                );
            }
        }

        // ── Validate product variables ──
        const allVariables = await prisma.productVariable.findMany({
            where: { productId: { in: productIds } },
        });
        for (const v of allVariables) {
            if (v.required) {
                const val = variables?.[v.productId]?.[v.name];
                if (!val || val.trim() === "") {
                    return NextResponse.json({
                        error: `${v.label} is required for product`,
                    }, { status: 400 });
                }
            }
        }

        // ── Fetch bulk discounts ──
        // No ordering: the rung is the best one the quantity reaches, chosen
        // by the same function the product page quotes from, so the order
        // they arrive in stopped mattering.
        const bulkDiscounts = await prisma.bulkDiscount.findMany({
            where: { isActive: true },
        });

        // ── Cumulative upgrade check ──
        // The same set every screen ahead of this one asked for, so the price
        // quoted on the card, the product page, the cart and the comparison
        // table is the price taken here. It is empty where the operator has
        // turned the credit off, and a lapsed purchase stops crediting.
        const ownedIds = await creditingPurchases(session.user.id);

        // Read once for the basket, as the listing reads them once a page.
        const campaignEntries = await runningCampaignEntries(prisma, now, zone);

        // ── Calculate item prices (with bulk discounts + cumulative upgrades) ──
        const storeSales = await runningStoreSales(now);
        const { subtotal, orderItems } = computeOrderPricing({
            items,
            products: products.map((p) => ({
                id: p.id,
                name: p.name,
                type: p.type,
                // What the shelf shows, not what the column says: a sale, a
                // running campaign or a store-wide sale sets it, and a checkout
                // that charged the column would take a different amount from
                // the one on screen. The lowest offer wins; `withStoreSale`
                // keeps the lower of its own price and the one it is given.
                price: withStoreSale(
                    offerPrice({ ...rulesOf(p as unknown as ProductRow), id: p.id }, campaignEntries, now),
                    { listPrice: rulesOf(p as unknown as ProductRow).price, categoryId: p.categoryId },
                    storeSales,
                    now,
                ).price,
                categoryId: p.categoryId,
            })),
            bulkDiscounts,
            ownedProductIds: ownedIds,
            // From the shelf, not the basket: the rung somebody stands on is
            // the one product an upgrade does not contain.
            ownedRungs: await ownedRungsOn(products.map((p) => p.categoryId), ownedIds, now),
            variables,
        });

        // ── Apply coupon ──
        // If the user supplied a coupon code, reject the checkout with a
        // clear error when it doesn't apply (not found / inactive /
        // expired / usage cap / min-purchase). Previously an invalid
        // code was silently ignored - the customer paid full price with
        // no feedback that their code didn't work.
        let couponDiscount = 0;
        // Written on the order, so the customer's uses can be counted from
        // their orders: see `coupon-limit.ts`.
        let couponId: string | null = null;
        if (couponCode) {
            const { enableCoupons } = await moduleSettings<{ enableCoupons: boolean }>("store");
            if (!enableCoupons) {
                return NextResponse.json(
                    { error: "Coupon codes are not accepted", code: "coupons_off" },
                    { status: 400 },
                );
            }
            const couponError = await prisma.$transaction(async (tx): Promise<string | null> => {
                const found = await tx.coupon.findUnique({
                    where: { code: couponCode.toUpperCase() },
                });
                // Somebody else's personal coupon is a code this buyer does
                // not have, and is refused as one.
                const coupon = found && couponOpenTo(found, session.user.id) ? found : null;
                // Only the part of the basket the offer covers. A coupon
                // naming no product and no category covers all of it, which
                // is what every coupon written before there was a way to say
                // otherwise covers.
                const eligible = scopedSubtotal(
                    coupon ?? {},
                    orderItems.map((item) => ({
                        productId: item.productId,
                        price: item.price,
                        quantity: item.quantity,
                    })),
                    products.map((product) => ({ id: product.id, categoryId: product.categoryId ?? null })),
                );
                // How often this customer already used it, their unpaid
                // checkouts of the last hour included. The order is written
                // after this transaction, so two checkouts sent together can
                // both pass here; each is counted again under a lock when it
                // is paid, which is the count that decides.
                const used = coupon?.perCustomerLimit
                    ? await customerUses(tx, coupon.id, session.user.id, now)
                    : 0;
                const { code, discount } = computeCouponDiscount(coupon, subtotal, new Date(), eligible, used);
                if (code) return code;
                // Claim the use conditionally. The count read above is a
                // snapshot, so two orders redeeming the last use of a
                // single-use coupon both passed the check and both got the
                // discount. Welcome coupons and wheel prizes are issued with
                // usageLimit 1, so that is the common case, not the rare one.
                const claimed = await tx.coupon.updateMany({
                    where: {
                        id: coupon!.id,
                        ...(coupon!.usageLimit ? { usageCount: { lt: coupon!.usageLimit } } : {}),
                    },
                    data: { usageCount: { increment: 1 } },
                });
                if (claimed.count === 0) return "coupon_used_up";
                couponDiscount = discount;
                couponId = coupon!.id;
                return null;
            });
            if (couponError) {
                // The code is the message: what a shopper reads is chosen
                // where their language is known, which is not here.
                return NextResponse.json({ error: couponError, code: couponError }, { status: 400 });
            }
        }

        // ── Apply creator code ──
        let creatorDiscount = 0;
        let creatorCodeRecord: { id: string; code: string; creatorId: string; commissionPercent: number } | null = null;
        if (creatorCode) {
            const code = await prisma.creatorCode.findUnique({
                where: { code: creatorCode.toUpperCase() },
            });
            // Skip codes whose creator was deleted (creatorId becomes null on
            // user delete via SetNull); the discount + commission both require
            // a payable creator.
            if (code && code.isActive && code.creatorId && code.creatorId !== session.user.id) {
                // Only the part the code covers. A code naming nothing covers
                // the basket, which is what every code issued before there
                // was a way to say otherwise covers.
                const eligible = scopedSubtotal(
                    code,
                    orderItems.map((item) => ({
                        productId: item.productId,
                        price: item.price,
                        quantity: item.quantity,
                    })),
                    products.map((product) => ({ id: product.id, categoryId: product.categoryId ?? null })),
                );
                creatorDiscount = computeCreatorDiscount(subtotal, couponDiscount, code.discountPercent, eligible);
                // A code that covered nothing in this basket earns its
                // creator nothing either: the commission is a share of what
                // the code actually moved.
                if (creatorDiscount > 0 || eligible > 0) {
                    creatorCodeRecord = {
                        id: code.id,
                        code: code.code,
                        creatorId: code.creatorId,
                        commissionPercent: code.commissionPercent,
                    };
                }
            }
        }

        // ── Tax calculation ──
        // Asked rather than read: the store's own two settings are the answer
        // only where no tax module gives one. A tax module may charge by the
        // buyer's country, which is why the billing form's country and the
        // request's address travel with the question. The form is read here
        // before it is checked below, because whether it is required depends
        // on the total and the total depends on the tax; a country that is
        // not a code is not one, and the answer says so.
        const currSetting = await prisma.setting.findUnique({ where: { key: "default_currency" } });
        const currency = resolveCurrency(currSetting?.value as string).toLowerCase();
        const sentForTax = sentBilling ? normaliseBilling(sentBilling) : null;
        const clientIp = getClientIP(request.headers);
        const taxAnswer = await resolveTax({
            channel: "checkout",
            currency: currency.toUpperCase(),
            billing: sentForTax
                ? { kind: sentForTax.kind, country: sentForTax.country, taxNumber: sentForTax.taxNumber }
                : null,
            ip: clientIp === "unknown" ? null : clientIp,
            header: headerReader(request.headers),
        });
        const taxRate = taxAnswer.rate;
        const taxIncluded = taxAnswer.included;
        const orderMetadata = {
            playerName,
            variables: variables || {},
            creatorCode: creatorCodeRecord?.code || null,
            // What was charged and why, for every screen that names the line
            // and for an invoice that has to say why a sale carries no tax.
            tax: taxRecord(taxAnswer) as unknown as Prisma.InputJsonObject,
        };

        const { totalDiscount, tax, total } = computeTotals({
            subtotal,
            couponDiscount,
            creatorDiscount,
            taxRate,
            taxIncluded,
        });

        // Who the invoice is made out to, if anything here issues one. Asked
        // before the money moves: afterwards these cannot be asked for at all.
        const needsBilling = await applyFiltersAsync("store.billing.required", false, {
            currency: currency.toUpperCase(),
            total,
        });
        const billingAnswer = billingRefusal(needsBilling, sentBilling);
        if ("missing" in billingAnswer) {
            return NextResponse.json(
                {
                    error: "Some invoice details are missing",
                    code: "billing_details_missing",
                    missing: billingAnswer.missing,
                },
                { status: 400 },
            );
        }
        // Prisma reads a JSON column as one type and writes it as another:
        // what comes back as null goes in as JsonNull.
        const billingDetails = billingAnswer.billing
            ? (billingAnswer.billing as unknown as Prisma.InputJsonValue)
            : Prisma.JsonNull;

        // ── Credits payment ──
        if (paymentMethod === "credits") {
            const user = await prisma.user.findUnique({ where: { id: session.user.id }, select: { creditBalance: true } });
            const balance = Number(user?.creditBalance || 0);

            if (balance < total) {
                // The code lets the cart say it in the buyer's language and
                // send them to the top-up page with what is missing.
                return NextResponse.json({
                    error: `Insufficient credit balance. You have ${balance.toFixed(2)} credits but need ${total.toFixed(2)}.`,
                    code: "store_insufficient_credits",
                    missing: Math.round((total - balance) * 100) / 100,
                }, { status: 400 });
            }

            // The money, the shelf, the order and what it grants, in one
            // transaction: `createCreditOrder` is shared with the game
            // servers that sell on the site's behalf, so both take a credit
            // payment the same way.
            // The limit is counted again under the lock the game takes: two
            // credits checkouts sent together both passed the count above.
            // The coupon's per-customer limit is counted again the same way.
            const buyerId = session.user.id;
            const order = await prisma.$transaction(async (tx) => {
                if (await pastTheLimit(tx, products, orderItems, buyerId, now)) return LIMIT_REACHED;
                if (await pastCouponLimit(tx, couponId, buyerId, now)) return COUPON_ALREADY_USED;
                return createCreditOrder(tx, {
                    buyerId,
                    ownerId: buyerId,
                    gift: false,
                    lines: orderItems.map((item) => ({
                        productId: item.productId,
                        name: item.name,
                        price: item.price,
                        quantity: item.quantity,
                        metadata: item.metadata as unknown as Prisma.InputJsonValue,
                    })),
                    subtotal,
                    discount: totalDiscount,
                    tax,
                    total,
                    currency,
                    notes,
                    billingDetails,
                    metadata: orderMetadata,
                    couponId,
                    playerName,
                    description: `Store purchase (${orderItems.map((i) => i.name).join(", ")})`,
                });
            });
            if (order === LIMIT_REACHED) {
                return NextResponse.json({ error: "limit_reached", code: "store_limit_reached" }, { status: 409 });
            }
            if (order === COUPON_ALREADY_USED) {
                return NextResponse.json({ error: "coupon_already_used", code: "coupon_already_used" }, { status: 409 });
            }

            // Delivery runs after the commit: a game server that is down must
            // not roll back an order somebody paid for. Not awaited, as
            // before, so a slow RCON does not hold the buyer's page.
            deliverPaidOrder(order, { name: playerName, id: null, userId: buyerId }).catch((err: unknown) =>
                log.error("[store] a checkout side effect failed", { error: err instanceof Error ? err.message : String(err) }),
            );

            // ── Update creator code stats ──
            if (creatorCodeRecord) {
                const code = creatorCodeRecord;
                await prisma.$transaction((tx) => payCreatorCommission(tx, code, total, order.orderNumber));
            }

            // ── Clear cart ──
            await prisma.cartItem.deleteMany({ where: { userId: session.user.id } });

            // ── Audit log + Discord ──
            logActivity({
                userId: session.user.id,
                action: "order.created",
                entity: "order",
                entityId: order.id,
                metadata: { orderNumber: order.orderNumber, total, paymentMethod: "credits" },
            }).catch((err: unknown) => log.error("[store] a checkout side effect failed", { error: err instanceof Error ? err.message : String(err) }));

            await announceOrderCreated(order.id);
            await announceOrderCompleted(order.id);
            return NextResponse.json({ order, redirect: null, message: "Order completed with credits" }, { status: 201 });
        }

        // Nothing is held for a PENDING order, so this cannot promise the
        // shelf will still cover it when the money lands - the conditional
        // take at settlement decides that. It is here so a shopper hears "we
        // are out of that" before a payment page rather than after.
        const unavailable = await shortOfStock(prisma, stockClaims(orderItems));
        if (unavailable.length > 0) {
            return NextResponse.json(
                { error: "One of these is no longer in stock.", code: "out_of_stock" },
                { status: 409 },
            );
        }

        // ── Create order (PENDING -- NO ownership granted yet) ──
        const order = await prisma.order.create({
            data: {
                orderNumber: generateOrderNumber(),
                userId: session.user.id,
                status: "PENDING",
                subtotal,
                discount: totalDiscount,
                tax,
                total,
                currency: currency.toUpperCase(),
                billingDetails,
                notes,
                paymentMethod,
                couponId,
                metadata: orderMetadata,
                items: { create: orderItems },
            },
        });

        // The creator's commission is paid when the money is: by
        // `settleOrder` for a gateway, below for a free order.

        // ── Clear cart ──
        await prisma.cartItem.deleteMany({ where: { userId: session.user.id } });

        // ── Audit log ──
        logActivity({
            userId: session.user.id,
            action: "order.created",
            entity: "order",
            entityId: order.id,
            metadata: { orderNumber: order.orderNumber, total },
        }).catch((err: unknown) => log.error("[store] a checkout side effect failed", { error: err instanceof Error ? err.message : String(err) }));

        await announceOrderCreated(order.id);

        // ── Free order: complete & grant immediately ──
        // CRITICAL: separated from the "no gateway" path below. If a paid
        // order arrives and no gateway can take it, refuse it instead of
        // silently giving the product away.
        if (total <= 0) {
            // One transaction, like the credits path above and the gateway
            // path in settleOrder: completing the order and granting what it
            // holds either both happen or neither does. Done in sequence, a
            // process that died in between left a COMPLETED order with an
            // empty chest and nothing that would ever go back and fix it.
            // It takes the shelf and counts the limit again under the same
            // lock, as the credits path does: a free order is still a sale.
            // The order written above is left out of that count, or it would
            // be counted against itself.
            const freeBuyerId = session.user.id;
            const freeCode = creatorCodeRecord;
            try {
                await prisma.$transaction(async (tx) => {
                    if (await pastTheLimit(tx, products, orderItems, freeBuyerId, now, order.id)) {
                        throw new Error(LIMIT_REACHED);
                    }
                    if (await pastCouponLimit(tx, couponId, freeBuyerId, now, order.id)) {
                        throw new Error(COUPON_ALREADY_USED);
                    }
                    const claims = stockClaims(orderItems);
                    if ((await claimStock(tx, claims)).length > 0) throw new Error(OUT_OF_STOCK);
                    await countSales(tx, claims);
                    await tx.order.update({ where: { id: order.id }, data: { status: "COMPLETED" } });
                    if (freeCode) await payCreatorCommission(tx, freeCode, total, order.orderNumber);
                    await tx.chestItem.createMany({
                        data: orderItems.map((item) => ({
                            userId: freeBuyerId,
                            productId: item.productId,
                            productName: item.name,
                            quantity: item.quantity,
                            orderId: order.id,
                            playerName,
                            variables: recordedVariables(item.metadata) ?? Prisma.JsonNull,
                        })),
                    });
                    await tx.ownedProduct.createMany({
                        data: [...new Set(orderItems.map((item) => item.productId))].map((productId) => ({
                            userId: freeBuyerId,
                            productId,
                            orderId: order.id,
                        })),
                        skipDuplicates: true,
                    });
                });
            } catch (error) {
                // A refused order must not sit PENDING, where it would hold
                // the buyer's allowance for an hour.
                const message = error instanceof Error ? error.message : "";
                if (message !== LIMIT_REACHED && message !== OUT_OF_STOCK && message !== COUPON_ALREADY_USED) throw error;
                await prisma.order.update({ where: { id: order.id }, data: { status: "CANCELLED" } });
                if (message === OUT_OF_STOCK) throw error;
                if (message === COUPON_ALREADY_USED) {
                    return NextResponse.json({ error: "coupon_already_used", code: "coupon_already_used" }, { status: 409 });
                }
                return NextResponse.json({ error: "limit_reached", code: "store_limit_reached" }, { status: 409 });
            }

            await announceOrderCompleted(order.id);
            return NextResponse.json({ order, redirect: null, message: "Order completed (free)" }, { status: 201 });
        }

        // A paid order whose gateway is not installed or not configured stays
        // PENDING, and nothing is granted.
        const chosen = (await listPaymentProviders(currency)).find((p) => p.id === paymentMethod);
        if (!chosen) {
            return NextResponse.json(
                {
                    error: "That payment method is not available. Ask an administrator to set up a payment gateway.",
                    code: "payment_not_configured",
                },
                { status: 503 },
            );
        }

        const buyer = await prisma.user.findUnique({
            where: { id: session.user.id },
            select: { email: true, username: true },
        });

        const lines = orderItems.map((item) => ({
            name: item.name,
            quantity: item.quantity,
            unitAmount: item.price,
        }));
        if (tax > 0) {
            // Only when it is added on top. Tax already inside the prices is
            // inside the line amounts too, and sending it again would charge
            // the buyer for it twice.
            if (!taxIncluded) {
                lines.push({ name: processorTaxLine(taxAnswer), quantity: 1, unitAmount: tax });
            }
        }

        // What this method costs, when the operator chose to pass it on: their
        // row for it, or the gateway's own offer. Grossed up rather than
        // added: the processor takes its cut of the larger amount too, so
        // adding the percentage leaves the shop short by almost exactly the
        // fee it was avoiding. See `grossUpForFee`.
        //
        // In the order's currency, before the conversion below: that one
        // converts the whole charge, fee included, exactly once.
        const resolvedFee = await paymentFeeFor(chosen, currency);
        if (!resolvedFee.ok) {
            // Like a missing exchange rate below: the order keeps its PENDING
            // row, and the fee is not dropped or charged in the wrong
            // currency, because either is an amount nobody chose.
            return NextResponse.json(
                {
                    error: "That payment method cannot be used right now: its fee cannot be converted into this currency.",
                    code: resolvedFee.code,
                },
                { status: 503 },
            );
        }
        const { charged, surcharge } = resolvedFee.fee
            ? grossUpForFee(total, resolvedFee.fee)
            : { charged: total, surcharge: 0 };
        if (surcharge > 0) {
            // Named rather than folded into the total: a charge a buyer cannot
            // account for is a chargeback waiting.
            //
            // English, like the tax line above it. These are handed to a
            // processor to print on its own checkout, not rendered by us, and
            // they travel with no locale; translating one of the two would
            // leave a receipt reading half in each.
            lines.push({ name: "Payment processing fee", quantity: 1, unitAmount: surcharge });
        }

        // A gateway that only settles in its own currency is handed a
        // converted amount, or nothing at all. Charging its currency with the
        // shop's number is the failure that looks like it worked: 100 becomes
        // 100 in a currency worth a fraction of it, and the order is paid.
        const settleIn = chosen.settlesIn ? resolveCurrency(chosen.settlesIn) : currency;
        let settleAmount = charged;
        if (settleIn !== currency) {
            const rate = await applyFiltersAsync("currency.rate", null, {
                from: currency,
                to: settleIn,
            });
            const converted = convertedCharge(charged, rate);
            if (converted === null) {
                // The order keeps its PENDING row and nothing is granted, so
                // an operator can fix the rate and the buyer can try again.
                return NextResponse.json(
                    {
                        error: "That payment method cannot be used right now: the exchange rate is unavailable.",
                        code: "exchange_rate_unavailable",
                    },
                    { status: 503 },
                );
            }
            settleAmount = converted;
        }

        // Written down before the gateway is asked, so the settlement that
        // comes back is held against what was charged rather than taking the
        // gateway's word for it. See `chargeShortfall`. The fee goes beside
        // it in the order's own currency, apart from `total`, so what was
        // sold and what the processor was paid stay two numbers.
        await prisma.order.update({
            where: { id: order.id },
            data: { chargeAmount: settleAmount, chargeCurrency: settleIn, paymentFee: surcharge },
        });

        const subProduct = isSubscriptionCheckout ? subscriptionProducts[0] : null;

        const payment = await startPaymentSession({
            provider: paymentMethod,
            kind: subProduct ? "subscription" : "order",
            reference: order.id,
            amount: settleAmount,
            currency: settleIn,
            description: `Order ${order.orderNumber}`,
            lines,
            customer: {
                userId: session.user.id,
                email: buyer?.email ?? null,
                name: buyer?.username ?? null,
            },
            // The discount travels as a total, not as a negative line: most
            // gateways reject a negative amount outright.
            metadata: {
                orderId: order.id,
                // What the buyer sees on their confirmation. A gateway that
                // puts a reference on a statement, or asks the buyer to quote
                // one, needs the readable number rather than the row id.
                orderNumber: order.orderNumber,
                userId: session.user.id,
                playerName,
                ...(totalDiscount > 0 ? { discount: totalDiscount.toFixed(2) } : {}),
            },
            ...(subProduct
                ? {
                      recurring: {
                          interval: (subProduct.subscriptionInterval as "month" | "year") || "month",
                          intervalCount: subProduct.subscriptionIntervalCount || 1,
                          productId: subProduct.id,
                      },
                  }
                : {}),
        });

        if (!payment.handled || !payment.redirectUrl) {
            return NextResponse.json(
                {
                    error: payment.error ?? "The payment could not be started. Try again shortly.",
                    code: payment.handled ? "payment_failed" : "payment_not_configured",
                },
                { status: payment.handled ? 502 : 503 },
            );
        }

        if (payment.reference) {
            await prisma.order.update({ where: { id: order.id }, data: { paymentId: payment.reference } });
        }

        return NextResponse.json({ order, redirect: payment.redirectUrl }, { status: 201 });
    } catch (error) {
        // The conditional debit lost the race: another checkout spent the
        // balance between the read and the write. Same answer the read gave
        // when it saw too little, not a 500.
        if (error instanceof Error && error.message === "OUT_OF_STOCK") {
            return NextResponse.json(
                { error: "One of these is no longer in stock.", code: "out_of_stock" },
                { status: 409 },
            );
        }
        if (error instanceof Error && error.message === "INSUFFICIENT_CREDITS") {
            return NextResponse.json(
                { error: "Insufficient credit balance.", code: "store_insufficient_credits" },
                { status: 400 },
            );
        }
        log.error("Checkout error", { error: error instanceof Error ? error.message : String(error) });
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}
